const salaryInfo = {
    "empId": "",
    "empName": "",
    "basicSalary": "",
    "laborInsuranceGrade": "",
    "laborVolunteerPensionRate": "",
    "healthInsuranceGrade": "",
    "familyDependantsNum": "",
    "welfareBenefitsDeduction": ""
}

export default salaryInfo;