import { ref } from 'vue';
export const dept = ref(
    {
        "deptName": "",
        "deptOffice": "",
    }
)

export default dept;