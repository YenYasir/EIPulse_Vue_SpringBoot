package com.eipulse.teamproject.controller.shoppingcontroller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderItemController {
}
