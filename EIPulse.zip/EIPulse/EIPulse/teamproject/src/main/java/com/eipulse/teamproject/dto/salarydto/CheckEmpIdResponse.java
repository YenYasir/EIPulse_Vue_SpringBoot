package com.eipulse.teamproject.dto.salarydto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckEmpIdResponse {
	
	private Integer EmpId;
	
	private String EmpName;
	
	private String status;
	
	
	
	public CheckEmpIdResponse() {
		// TODO Auto-generated constructor stub
	}

}
