package com.eipulse.teamproject.dto.shoppingdto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShoppingCartDTO {

}
